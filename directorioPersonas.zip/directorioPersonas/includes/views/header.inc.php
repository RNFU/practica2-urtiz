<!DOCTYPE HTML>
<html>

<head>
	<title>Simple cat&aacute;logo </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?php echo $url;?>assets/css/bootstrap.min.css">
<head>
	
<body class="page">
<header>
    <nav role="navigation">
        <div class="container">
            <div class="page-header">
                <h1>Direcci&oacute;n de sistemas <small>Cat&aacute;logo de personas</small></h1>
            </div>
        </div>
    </nav>        
</header>
<hr />
<!-- end of header -->


	<!-- div class="container">

		<h1>Simple Blog - MySqli</h1>
		<h3><a href="create.php">Add Post</a></h3><hr / -->
